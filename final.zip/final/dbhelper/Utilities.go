package dbhelper

import (
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
	"os"
	"strings"
)

var DB *gorm.DB

type CustomNamingStrategy struct {
	schema.NamingStrategy
}

func (c CustomNamingStrategy) TableName(model string) string {
	return strings.ToLower(c.NamingStrategy.TableName(model))
}

func GetOpenConnection() (*gorm.DB, error) {
	host := os.Getenv("DB_HOST")
	port := os.Getenv("DB_PORT")
	dbName := os.Getenv("DB_NAME")
	user := os.Getenv("DB_USER")
	password := os.Getenv("DB_PASSWORD")

	if host == "" || port == "" || dbName == "" || user == "" || password == "" {
		return nil, fmt.Errorf("database environment variables are not set")
	}

	dsn := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8mb4&parseTime=True&loc=Local",
		user, password, host, port, dbName)
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{
		NamingStrategy: CustomNamingStrategy{
			NamingStrategy: schema.NamingStrategy{
				SingularTable: true,
			},
		},
	})
	if err != nil {
		return nil, err
	}

	return db, nil
}

func CloseConnection(db *gorm.DB) error {
	if db != nil {
		sqlDB, err := db.DB()
		if err != nil {
			return err
		}
		return sqlDB.Close()
	}
	return nil
}
